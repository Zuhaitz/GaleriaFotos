package com.example.eval2_galeria;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.ListFragment;

import java.util.ArrayList;

public class ListaCPImagenes extends ListFragment {

    private AdapterCPListView adap;
    private ArrayList<String> nombres;
    private ArrayList<String> espacio;
    private ArrayList<String> identif;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Inicializamos las variables
        nombres = new ArrayList<>();
        espacio = new ArrayList<>();
        identif = new ArrayList<>();

        //Comprobamos si hay datos guardados
        if(savedInstanceState != null){
            nombres = savedInstanceState.getStringArrayList("nombres");
            espacio = savedInstanceState.getStringArrayList("espacio");
        }else{
            //Comprobamos si tiene los permisos
            if(tienePermisos()){
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
            }else {
                inicializar();
            }
        }
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        adap = new AdapterCPListView(getActivity(), nombres, espacio, identif);

        setListAdapter(adap);
    }


    /*
    Inicializa los elementos de la lista con los datos proporcionados por el Content Provider
    pre: Que las listas esten vacias
    post: las listas tienen los elementos asignados
     */
    public void inicializar(){
        if(adap != null) {
            String[] columnas = new String[]{
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media._ID};

            String orden = MediaStore.Images.Media.SIZE + " DESC";

            Cursor cursor = getContext().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columnas,
                    null, null, orden);

            while (cursor.moveToNext()) {
                String display = cursor.getString(0);
                String size = cursor.getString(1);
                String id = cursor.getString(2);
                //Comprobamos si tiene nombre la imagen
                if (display != null) nombres.add(display);
                else nombres.add("SIN NOMBRE");
                espacio.add(size);
                identif.add(id);
            }

            Log.i("Identificadores", identif.toString());
            adap.notifyDataSetChanged();
        }
    }

    /*
    Se comprueba si se tienen los permisos necesarios
    pre: -
    post: se devuleve un booleano con el resultado
            TRUE: No tiene permisos
            FALSE: Tiene los permisos
     */
    private boolean tienePermisos(){
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.i("Permiso", "Entra en permiso result");
        switch (requestCode){
            case 22:{
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED /*&& grantResults[1] == PackageManager.PERMISSION_GRANTED*/){
                    inicializar();
                }else{
                    // Si la petición se cancela
                    Activity a = getActivity();
                    Intent i = new Intent(a, MainActivity.class);
                    i.putExtra("permiso", false);
                    startActivity(i);
                    a.finish();
                }
                break;
            }
        }
    }

    /*
    Limpia las listas
    pre: -
    post: se vacian las listas
     */
    public void limpiar(){
        if(adap != null) {
            nombres.clear();
            espacio.clear();
            identif.clear();

            adap.notifyDataSetChanged();
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArrayList("nombres", nombres);
        outState.putStringArrayList("espacio", espacio);

    }
}
