package com.example.eval2_galeria;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import static android.app.Activity.RESULT_OK;

public class DialogoAdd extends DialogFragment {

    ListenerDialogoAdd listener;
    View aspecto;
    TextView titulo;
    TextView descrip;
    ImageView imageView;
    Button botonAceptar;

    @Nullable
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState){
        super.onCreateDialog(savedInstanceState);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Añadir nuevo elemento");
        LayoutInflater inflater = getActivity().getLayoutInflater();
        aspecto = inflater.inflate(R.layout.dialoganadir, null);
        builder.setView(aspecto);

        listener = (MainActivity) getActivity();

        //Recogemos los diferentes elementos del Dialog, para luego poder revisar su contenido
        titulo = aspecto.findViewById(R.id.tituloA);
        descrip = aspecto.findViewById(R.id.descripA);
        imageView = aspecto.findViewById(R.id.imagenA);
        botonAceptar = aspecto.findViewById(R.id.guardar);

        crearListeners();

        if (savedInstanceState!=null){
            titulo.setText(savedInstanceState.getString("titulo"));
            descrip.setText(savedInstanceState.getString("descrip"));
            String path = savedInstanceState.getString("imagen");
            if(path!=null){
                try {
                    Bitmap b = BitmapFactory.decodeStream(getContext().openFileInput(path));
                    imageView.setImageBitmap(b);
                    imageView.setBackground(null);
                    File dir = getContext().getFilesDir();
                    File file = new File(dir, path);
                    boolean deleted = file.delete();
                    Log.i("Borrado foto ADD", ""+deleted);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }

        return builder.create();
    }

    /*
    Se encarga de crear los listeners del Dialog
    pre: -
    post: Los botones son funcinales
     */
    private void crearListeners(){
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Aqui se solicita al usuario que escoja una imagen de su movil
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (i.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivityForResult(i, 0);
                }
            }
        });

        botonAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Pulsado el boton", "Titulo: " + titulo.getText() + ", Descrip: " + descrip.getText() + ", Imagen: " + (imageView.getDrawable() != null));

                //Se comprueba si todos los aparatados se rellenaron
                if(titulo.getText().length() > 0 && descrip.getText().length() > 0 && imageView.getDrawable() != null){
                    Drawable d = imageView.getDrawable();
                    Bitmap bitmap = ((BitmapDrawable)d).getBitmap();
                    String tit = titulo.getText().toString();
                    String des = descrip.getText().toString();

                    listener.pulsarGuardar(tit, des, bitmap);
                    getDialog().dismiss();
                }else{
                    //Se crea un Toast para notificar al usuario que falta algo
                    Toast toast = Toast.makeText(getContext(), "Rellena todos los apartados",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i("Cogido imagen", "Entra en onActivityResult");

        //Comprobamos que la solicitud de la imagen sea correcta
        if(requestCode == 0 && resultCode == RESULT_OK){
            Log.i("Cogido imagen", "Entra en el if");

            //Recogemosla imagen y se la asignamos a la imagen del Dialog
            Bundle extras = data.getExtras();
            Bitmap selectedImage = (Bitmap) extras.get("data");

            //Reescalamos la imagen para que no se tan grande
            Bitmap escalado = escalarImagen(selectedImage);

            imageView.setImageBitmap(escalado);
            imageView.setBackground(null);
        }
    }

    /*
    Escala la imagen para que no se tan grande
    pre: -
    post: Un bitmap con la escala reducida
     */
    private Bitmap escalarImagen(Bitmap img){
        int anchoDestino = imageView.getWidth();
        int altoDestino = imageView.getHeight();

        Log.i("Dimensiones destino", "Ancho: " + anchoDestino + " Alto: " + altoDestino);

        int anchoImagen = img.getWidth();
        int altoImagen = img.getHeight();
        Log.i("Dimensiones imagen", "Ancho: " + anchoImagen + " Alto: " + altoImagen);

        /*float ratioImagen = (float) anchoImagen / (float) altoImagen;
        float ratioDestino = (float) anchoDestino / (float) altoDestino;
        int anchoFinal = anchoDestino;
        int altoFinal = altoDestino;
        if (ratioDestino > ratioImagen) {
            anchoFinal = (int) ((float)altoDestino * ratioImagen);
        } else {
            altoFinal = (int) ((float)anchoDestino / ratioImagen);
        }*/
        int ratioAncho = (int) (anchoImagen * 0.75);
        int ratioAlto = (int) (altoImagen * 0.75);


        Bitmap bitmapredimensionado = Bitmap.createScaledBitmap(img, ratioAncho, ratioAlto, true);

        return bitmapredimensionado;
    }

    public interface ListenerDialogoAdd{
        void pulsarGuardar(String titulo, String descrip, Bitmap img);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("titulo", titulo.getText().toString());
        outState.putString("descrip", descrip.getText().toString());
        if(imageView.getDrawable() != null) {
            Drawable d = imageView.getDrawable();
            Bitmap bitmap = ((BitmapDrawable) d).getBitmap();
            String path = createImageFromBitmap(bitmap);
            outState.putString("imagen", path);
        }

    }

    // Source: https://stackoverflow.com/questions/4352172/how-do-you-pass-images-bitmaps-between-android-activities-using-bundles
    // Creador: Illegal Argument
    public String createImageFromBitmap(Bitmap bitmap) {
        String fileName = "imagenAdd";//no .png or .jpg needed
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            FileOutputStream fo = getContext().openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            // remember close file output
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }
}
