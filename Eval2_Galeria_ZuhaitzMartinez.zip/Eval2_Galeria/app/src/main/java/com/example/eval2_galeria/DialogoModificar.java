package com.example.eval2_galeria;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;


public class DialogoModificar extends DialogFragment {

    ListenerDialogModif listener;
    View aspecto;
    EditText titulo;
    EditText descrip;
    Button botonAceptar;


    @Nullable
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        super.onCreateDialog(savedInstanceState);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Modificar nuevo elemento");
        LayoutInflater inflater = getActivity().getLayoutInflater();
        aspecto = inflater.inflate(R.layout.dialogmodif, null);
        builder.setView(aspecto);

        listener = (DetallesActivity) getActivity();

        //Recogemos los diferentes elementos del Dialog, para luego poder revisar su contenido
        titulo = aspecto.findViewById(R.id.tituloE);
        descrip = aspecto.findViewById(R.id.descripE);
        titulo.setText(getArguments().getString("titulo"));
        descrip.setText(getArguments().getString("descrip"));

        botonAceptar = aspecto.findViewById(R.id.modificar);
        botonAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Pulsado el boton", "Titulo: " + titulo.getText() + ", Descrip: " + descrip.getText());

                //Se comprueba si todos los aparatados se rellenaron
                if(titulo.getText().length() > 0 && descrip.getText().length() > 0){
                    String tit = titulo.getText().toString();
                    String des = descrip.getText().toString();

                    listener.pulsarModif(tit, des);
                    getDialog().dismiss();
                }else{
                    //Se crea un Toast para notificar al usuario que falta algo
                    Toast toast = Toast.makeText(getContext(), "Rellena todos los apartados",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        //Cargamos los datos guardado si existen
        if(savedInstanceState!=null) {
            titulo.setText(savedInstanceState.getString("titulo"));
            descrip.setText(savedInstanceState.getString("descrip"));
        }

        return builder.create();
    }

    public interface ListenerDialogModif{
        void pulsarModif(String titulo, String descrip);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("titulo", titulo.getText().toString());
        outState.putString("descrip", descrip.getText().toString());

    }
}
