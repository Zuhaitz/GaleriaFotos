package com.example.eval2_galeria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroActivity extends AppCompatActivity {

    EditText campoNom;
    EditText campoCon;
    EditText campoRep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        campoNom = findViewById(R.id.usuRegis);
        campoCon = findViewById(R.id.contraRegis);
        campoRep = findViewById(R.id.repetirContraRegis);

        //Inicailizar el boton de aceptar el registro
        Button aceptar = findViewById(R.id.aceptarRegis);
        aceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usu = campoNom.getText().toString();
                String con = campoCon.getText().toString();
                String rep = campoRep.getText().toString();

                //Comprobar los textos
                if(usu.length()>0 && con.length()>5 && rep.length()>5 && con.equals(rep)){
                    registroUsuario(usu, con);

                }else {
                    //Mostrar mensaje de error
                    Toast t = Toast.makeText(getApplicationContext(), "Usuario vacio o las contraseñas no coinciden", Toast.LENGTH_SHORT);
                    t.show();
                }
            }
        });

        //Inicailizar el boton de cancelar el registro
        Button cancelar = findViewById(R.id.cancelarRegis);
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RegistroActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });

    }


    private void registroUsuario(String nom, String con){
        //Recogemos el token del dispositivo para la mensajeria FCM
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String token = sp.getString("token", "");

        //Creamos el paquete de datos
        Data datos = new Data.Builder()
                .putString("operacion", "Registro")
                .putString("nombre", nom)
                .putString("contra", con)
                .putString("token", token)
                .build();

        //Restringimos para que solo se lance con conexion
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(conexionBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                //Se ha registrado el usuario
                                Toast t = Toast.makeText(getApplicationContext(), "¡Usuario creado con exito!", Toast.LENGTH_SHORT);
                                t.show();

                                Intent i = new Intent(RegistroActivity.this, LoginActivity.class);
                                startActivity(i);
                                finish();

                            }else if (workInfo.getState().name().equals("FAILED")){
                                //No se ha registrado el usuario
                                Toast t;
                                Log.i("Resultado error", workInfo.getOutputData().getString("resultado"));

                                if (workInfo.getOutputData().getString("resultado").contains("Duplicate"))
                                    t = Toast.makeText(getApplicationContext(), "El usuario ya existe.", Toast.LENGTH_SHORT);

                                else t = Toast.makeText(getApplicationContext(), "Error al añadir el usuario.", Toast.LENGTH_SHORT);

                                t.show();
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }
}
