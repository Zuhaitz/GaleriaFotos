package com.example.eval2_galeria;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;


import com.google.android.material.navigation.NavigationView;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity implements ListaFotos.listenerFragment,
                                                                DialogoAdd.ListenerDialogoAdd {
    private boolean inicio = true;
    private boolean cambio = false;

    private DrawerLayout elmenudesplegable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawerlayout);
        Toolbar barra=findViewById(R.id.barra);
        setSupportActionBar(barra);

        //Creamos el drawer con las opciones correspondientes
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.baseline_list_black_18dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        crearDrawer();


        //Recogemos el nombre del usuario logeado
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");
        Log.i("Usuario", log);

        //Se le añade un listener al boton para lanzar un Dialog
        //para que el usuario pueda añadir un elemento
        Button button = findViewById(R.id.anadir);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogo = new DialogoAdd();
                dialogo.show(getSupportFragmentManager(), "anadir");
            }
        });

        //Recogemos el boton de borrado y lo ocultamos,
        // para que solo sea visible al marcar una checkbox
        Button borrar = findViewById(R.id.borrar);
        borrar.setVisibility(View.GONE);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListaFotos lista = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
                lista.borrarChecked();
                Button borrar = findViewById(R.id.borrar);
                borrar.setVisibility(View.GONE);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Entra en onStart", "A vuelto correctamente");

        //Se controla si el usuario le dio hacia atras en vez de al boton volver
        if(!inicio){
            if(cambio){
                ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
                Log.i("Entra en cambio", "Inicailizar list");
                cambio=false;

            }
        }

        inicio = false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();
        Log.i("Entra en NewIntent", "A vuelto correctamente");

        //Aqui controlamos cuando el usuario decide volver y a modificado algun dato
        if (extras != null){
            if(extras.containsKey("permiso")) avisoPermiso();
            else{
                Log.i("Entra en NewIntent", "Recibe extras");
                ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
                list.modificarLista(extras.getString("fecha"), extras.getString("titulo"), extras.getString("descrip"));
                cambio = true;
            }
        }else{
            cambio=false;
        }

    }

    public void seleccionarElemento(String fecha, String elemento, String descrip, Bitmap imagen) {

        //Comprobamos si el movil esta en apaisado
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            //Le pasamos al otro fragment la informacion
            DetallesFoto det = (DetallesFoto) getSupportFragmentManager().findFragmentById(R.id.detalles);
            det.añadirImagen(elemento, descrip, imagen);

        }
        else {
            //Creamos un intent y le enviamos a la otra actividad la informacion
            Intent i = new Intent(MainActivity.this, DetallesActivity.class);
            i.putExtra("fecha", fecha);
            i.putExtra("titulo", elemento);
            i.putExtra("descrip", descrip);

            //Guardamos la imagen en local, ya que no es conveniente
            //pasar imagenes a traves de los intents
            String path = createImageFromBitmap(imagen);
            i.putExtra("imagen", path);
            startActivity(i);

        }
    }

    /*
    Se encarga de inicializar el Drawer de la barra de la aplicacion
    Pre:-
    Post: el drawer con las opciones a elegir
     */
    private void crearDrawer(){
        elmenudesplegable = findViewById(R.id.drawer_layout);
        NavigationView elnavigation = findViewById(R.id.elnavigationview);
        elnavigation.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Intent i;
                switch (menuItem.getItemId()){
                    case R.id.almacen:
                        //Abrimos la actividad encargada de gestionar las fotos del movil
                        i = new Intent(MainActivity.this, ImageCPActivity.class);
                        startActivity(i);

                        break;
                    case R.id.cerrarSesion:
                        //Borramos los datos de sesion de la aplicacion
                        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
                        sp.edit().remove("nombreUsuario").apply();

                        //Devolvemos al usuario a l pantalla de login
                        i = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(i);
                        finish();
                        break;
                }
                elmenudesplegable.closeDrawers();
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                elmenudesplegable.openDrawer(GravityCompat.START);
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (elmenudesplegable.isDrawerOpen(GravityCompat.START)) {
            elmenudesplegable.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    /*
    Avisa al usuario de la importancia de los permisos
    pre: conocer si no se dispone de los permisos
    post: Se habre un dialog para que avisar al usuario
     */
    private void avisoPermiso(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //EL PERMISO NO ESTÁ CONCEDIDO TODAVÍA
        builder.setTitle("Permiso de acceso");
        builder.setMessage("Es necesario dar permiso a la aplicaión para acceder a esta funcionalidad que permite borrar las fotos de tu móvil.");
        builder.setPositiveButton("Dar permiso", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        });
        builder.create().show();

    }

    // Source: https://stackoverflow.com/questions/4352172/how-do-you-pass-images-bitmaps-between-android-activities-using-bundles
    // Creador: Illegal Argument
    public String createImageFromBitmap(Bitmap bitmap) {
        String fileName = "myImage";//no .png or .jpg needed
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            FileOutputStream fo = openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            // remember close file output
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }


    @Override
    public void pulsarGuardar(String titulo, String descrip, Bitmap img) {
        //Recojemos los datos introducidos en el dialog, y los añadimos a la lista
        ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
        list.anadirImagen(titulo, descrip, img);
    }

    @Override
    public void comprobar(){
        //Comprobamos si esta en landscape para resetar la imagen de detalles
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            //Reseteamos el fragment
            DetallesFoto det = (DetallesFoto) getSupportFragmentManager().findFragmentById(R.id.detalles);
            det.reset();

        }
    }


}
