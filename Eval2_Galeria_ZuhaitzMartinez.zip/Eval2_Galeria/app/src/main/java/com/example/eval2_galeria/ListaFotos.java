package com.example.eval2_galeria;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.ListFragment;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class ListaFotos extends ListFragment {

    private listenerFragment listener;
    private AdapterListView adap;
    private ArrayList<String> fechas;
    private ArrayList<Bitmap> imagenes;
    private ArrayList<String> titulos;
    private ArrayList<String> descrip;

    private boolean init = false;


    public ListaFotos() { }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setRetainInstance para que las imagenes se mantengan
        setRetainInstance(true);

        //Inicializamos las variables
        fechas = new ArrayList<>();
        titulos = new ArrayList<>();
        imagenes = new ArrayList<>();
        descrip = new ArrayList<>();

        inicializar();
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        adap = new AdapterListView(getActivity(), titulos, imagenes);

        if(savedInstanceState!=null){
            ArrayList<Integer> s = savedInstanceState.getIntegerArrayList("checked");
            adap.setCheckedList(s);
        }

        setListAdapter(adap);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l, v, position, id);
        listener.seleccionarElemento(fechas.get(position), titulos.get(position), descrip.get(position), imagenes.get(position));
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            listener = (listenerFragment) context;
        }
        catch (ClassCastException e) {
            throw new ClassCastException("La clase " + context.toString()
                        + "debe implementar listenerFragment");
        }
    }


    public void anadirImagen(String titulo, String des, Bitmap img){
        Date currentTime = Calendar.getInstance().getTime();
        //Añadimos el nuevo elemento a la lista
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());

        anadirImagenW(timeStamp, titulo, des, img);
    }

    /*
    Se encarga de comunicarse con el servidor para añadir una nueva imagen
    Pre: -
    Post: Se añadio la imagen correctamente
     */
    private void anadirImagenW(String fecha, String titulo, String des, Bitmap img){

        SharedPreferences sp = getContext().getSharedPreferences("login", getContext().MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        String path = createImageFromBitmap(img, fecha);

        //Generamos los datos a pasar
        Data datos = new Data.Builder()
                .putString("operacion", "AnadirImagen")
                .putString("usuario", log)
                .putString("fecha", fecha)
                .putString("titulo", titulo)
                .putString("descrip", des)
                .putString("imagen", path)
                .build();

        //Creamos la restrccion de estar conectado a la red
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(imagenesBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                fechas.add(fecha);
                                titulos.add(titulo);
                                imagenes.add(img);
                                descrip.add(des);
                                adap.notifyDataSetChanged();

                                //Enviar la notificacion al usuario
                                enviarNotificacion(titulo, img);

                                //Enviar la notificacion al resto de usuarios con el servicio FCM
                                enviarNotificacionFCM();
                                //WorkManager.getInstance().pruneWork();

                            }else if (workInfo.getState().name().equals("FAILED")){
                                Log.i("Error AÑADIR",  workInfo.getOutputData().getString("resultado"));
                                Toast t = Toast.makeText(getContext(), "Error al añadir los datos.", Toast.LENGTH_SHORT);
                                t.show();
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }

    /*
    Borra todos los elementos que han sido marcados al pulsar el boton de 'Borrar'
    pre: se pulso el boton y hay elementos marcados
    post: se borran los elementos marcados
     */
    public void borrarChecked(){
        //Recogemos las posiciones de los elementos marcados y los ordenamos en forma descendente
        ArrayList<Integer> r = adap.getCheckedList();
        Collections.sort(r,  Collections.reverseOrder());
        Log.i("Borrar Checked", "Lista ordenada: " + r.toString());

        //Recogemos los identifcadores de los elementos a borrar
        String[] idBorrar = new String[r.size()];
        int j = 0;
        for (int i : r){
            idBorrar[j] = fechas.get(i);
            j++;
        }

        SharedPreferences sp = getContext().getSharedPreferences("login", getContext().MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        //Creamos la restrccion de estar conectado a la red
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        //Generamos los datos a pasar
        Data datos = new Data.Builder()
                .putString("operacion", "BorrarImagenes")
                .putString("usuario", log)
                .putStringArray("idBorrar", idBorrar)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(imagenesBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                for (int i : r){
                                    //Limpiamos los valores de la lista
                                    fechas.remove(i);
                                    titulos.remove(i);
                                    descrip.remove(i);
                                    imagenes.remove(i);
                                }

                                adap.resetCheckedList();
                                adap.notifyDataSetChanged();
                                listener.comprobar();
                                //WorkManager.getInstance().pruneWork();

                            }else if (workInfo.getState().name().equals("FAILED")){
                                Log.i("Error Borrar",  workInfo.getOutputData().getString("resultado"));
                                Toast t = Toast.makeText(getContext(), "Error al borrar los datos.", Toast.LENGTH_SHORT);
                                t.show();
                                adap.resetCheckedList();
                                adap.notifyDataSetChanged();
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);



    }

    /*
    Modifica la lista con los nuevos datos
    pre: se modifique un elemento
    post: aparece el elemento modificado
     */
    public void modificarLista(String fecha, String titulo, String des) {
        Log.i("Lista fotos", fechas.toString());
        Log.i("Pos " + fecha, ""+fechas.indexOf(fecha));
        Log.i("Lista titulo", titulos.toString());
        Log.i("Lista descrip", descrip.toString());
        int pos = fechas.indexOf(fecha);
        titulos.set(pos, titulo);
        descrip.set(pos, des);
        adap.notifyDataSetChanged();
    }

    /*
    Inicializa los elementos de la lista
    pre: Que las listas esten vacias
    post: las listas tienen los elementos asignados
     */
    public void inicializar(){
        SharedPreferences sp = getContext().getSharedPreferences("login", getContext().MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        //Generamos los datos a pasar
        Data datos = new Data.Builder()
                .putString("usuario", log)
                .build();

        //Creamos la restrccion de estar conectado a la red
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(listarImagenesBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        boolean ok = true;

                        if(workInfo != null && workInfo.getState().isFinished() && ok){
                            Log.i("Resultado worker Listar", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                //A realizado correctamente la operacion y cogemos los datos
                                limpiar();

                                String[] f = workInfo.getOutputData().getStringArray("fechas");
                                String[] t = workInfo.getOutputData().getStringArray("titulos");
                                String[] d = workInfo.getOutputData().getStringArray("descripciones");
                                String[] i = workInfo.getOutputData().getStringArray("imagenes");

                                for (int id = 0; id<f.length; id++){
                                    fechas.add(f[id]);
                                    titulos.add(t[id]);
                                    descrip.add(d[id]);
                                }

                                //Cargamos las imagenes guardada en local y las eliminamos para que no ocupen espacio
                                for (String img : i) {
                                    Bitmap b = null;
                                    try {
                                        b = BitmapFactory.decodeStream(getContext().openFileInput(img));
                                        File dir = getContext().getFilesDir();
                                        File file = new File(dir, img);
                                        boolean deleted = file.delete();
                                        Log.i("Borrado foto ini", ""+deleted);
                                    } catch (FileNotFoundException e) {
                                        e.printStackTrace();
                                    }
                                    imagenes.add(b);
                                }

                                Log.i("Lista fechas", fechas.toString());
                                adap.notifyDataSetChanged();
                                //WorkManager.getInstance().pruneWork();

                            }else if (workInfo.getState().name().equals("FAILED")){
                                Log.i("Error Cargar",  "Error al cargar");
                            }

                            //Nos desacemos del resultado
                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });


        WorkManager.getInstance().enqueue(otwr);
    }

    /*
    Envia una notificación cuando un elemento se añada
    pre: se añade un nuevo elemento
    post: se envia la notificacion
     */
    private void enviarNotificacion(String titulo, Bitmap img){
        NotificationManager mana = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder build = new NotificationCompat.Builder(getContext(), "added");

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel canal = new NotificationChannel("added", "AddedElem", NotificationManager.IMPORTANCE_DEFAULT);
            canal.setDescription("Canal de notificación al añadir nuevos elementos");
            canal.enableLights(true);
            canal.setLightColor(Color.RED);
            mana.createNotificationChannel(canal);
        }

        build.setSmallIcon(android.R.drawable.arrow_up_float)
                .setContentTitle("¡Nuevo elemento añadido!")
                .setContentText("Se ha añadido con exito un elemento a tu galeria personal.")
                .setSubText(titulo)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .setAutoCancel(true);

        mana.notify(1, build.build());
    }

    /*
    Envia una notificación cuando un elemento se añada
    pre: se añade un nuevo elemento
    post: se envia la notificacion
     */
    private void enviarNotificacionFCM(){
        SharedPreferences sp = getContext().getSharedPreferences("login", getContext().MODE_PRIVATE);
        String usu = sp.getString("nombreUsuario", "");
        String token = sp.getString("token", "");

        Data datos = new Data.Builder()
                .putString("usuario", usu)
                .putString("token", token)
                .build();

        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(conexionEnviarMensajeFCM.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().enqueue(otwr);


    }

    // Source: https://stackoverflow.com/questions/4352172/how-do-you-pass-images-bitmaps-between-android-activities-using-bundles
    // Creador: Illegal Argument
    // Modificado por Zuhaitz
    public String createImageFromBitmap(Bitmap bitmap, String fecha) {
        String fileName = "IMG_" + fecha + "_";//no .png or .jpg needed
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes);
            FileOutputStream fo = getActivity().openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            // remember close file output
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }



    /*
    Limpia las listas
    pre: -
    post: se vacian las listas
     */
    public void limpiar(){
        fechas.clear();
        titulos.clear();
        descrip.clear();
        imagenes.clear();

        adap.notifyDataSetChanged();
    }

    public interface listenerFragment{
        void seleccionarElemento(String fecha, String elemento, String descrip, Bitmap imagen);
        void comprobar();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArrayList("titulos", titulos);
        outState.putStringArrayList("descrip", descrip);
        outState.putIntegerArrayList("checked", adap.getCheckedList());

    }
}
