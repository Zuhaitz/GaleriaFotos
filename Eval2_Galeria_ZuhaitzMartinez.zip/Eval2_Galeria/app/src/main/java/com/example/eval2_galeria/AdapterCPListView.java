package com.example.eval2_galeria;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AdapterCPListView extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<String> nombres;
    private ArrayList<String> espacio;
    private ArrayList<String> identif;

    public AdapterCPListView(Context vContext, ArrayList<String> vNombres, ArrayList<String> vEspacio, ArrayList<String> vIdentif){
        context = vContext;
        nombres = vNombres;
        espacio = vEspacio;
        identif = vIdentif;

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return nombres.size();
    }

    @Override
    public Object getItem(int position) {
        return nombres.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.aspecto_lista_cp, null);
        TextView nombre = convertView.findViewById(R.id.nombreImagenCP);
        TextView peso = convertView.findViewById(R.id.tamanoImagenCP);
        Button b = convertView.findViewById(R.id.borrarCPbtn);

        nombre.setText(nombres.get(position));
        peso.setText(espacio.get(position));

        //Se añade como tag la posicion del elemento como referencia par mas tarde
        b.setTag(position);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = (int) v.getTag();
                String nombre = nombres.get(pos);
                String id = identif.get(pos);
                Log.i("Check Listener", "Se clico una imagen para borrar " + pos + ": " + nombre);

                //La condicion a borrar
                String cond = MediaStore.Images.Media._ID + " LIKE ?";
                String[] args = {id};

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                //Avisamos al usuario siquiere borrar la foto
                builder.setTitle("Aviso de borrado");
                builder.setMessage("¿Estás seguro que quieres borrar " + nombre + "?");
                builder.setPositiveButton("Borrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int numFilasEliminadas = context.getContentResolver().delete( MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                cond, args);

                        //Comprobamos que se borro correctamente
                        if (numFilasEliminadas == 1){
                            nombres.remove(pos);
                            espacio.remove(pos);
                            identif.remove(pos);
                            notifyDataSetChanged();
                        }else{
                            Toast t = Toast.makeText(context, "Error al borrar la imagen.", Toast.LENGTH_SHORT);
                            t.show();
                        }
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });


        return convertView;
    }
}
