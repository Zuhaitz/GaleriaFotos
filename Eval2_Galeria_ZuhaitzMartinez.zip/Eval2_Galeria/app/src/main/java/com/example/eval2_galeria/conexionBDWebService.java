package com.example.eval2_galeria;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class conexionBDWebService extends Worker {

    public conexionBDWebService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        //Recogemos e inicializamos los datos necesarios
        String op = getInputData().getString("operacion");
        String nombre = getInputData().getString("nombre");
        String contra = getInputData().getString("contra");
        String token = getInputData().getString("token");


        //Realizamos la conexion a la base de datos remota
        String result = usuarioBDWeb(op, nombre, contra, token);

        //Comprobamos si se ha realizado correctamente
        if (result.equals("True")) return Result.success();
        else {
            Data resultados = new Data.Builder()
                    .putString("resultado", result)
                    .build();
            return Result.failure(resultados);
        }

    }


    private String usuarioBDWeb(@NonNull String operacion, @NonNull String nombre, @NonNull String contra, @NonNull String token){
        Log.i("Conexion", "Nombre y Contra: " + nombre + contra);

        //Creamos la uri con los datos necesarios para la operacion
        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("operacion", operacion)
                .appendQueryParameter("nombre", nombre)
                .appendQueryParameter("contra", contra)
                .appendQueryParameter("token", token);

        String param = builder.build().getEncodedQuery();

        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/usuarios.php";

        //Generamos la conexion segura
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);

        //Creamos la conexion
        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Comprobamos el estado de la conexion
        int statusCode = 0;
        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("Conexion Base datos", "" + statusCode);

        if (statusCode == 200) {
            try {
                //Recogemos el resultado
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                String line, result="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                inputStream.close();
                Log.i("Resultado", "Resultado es: " + result);

                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return "False";
    }
}
