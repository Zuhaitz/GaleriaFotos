package com.example.eval2_galeria;


import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;



public class DetallesFoto extends Fragment {


    public DetallesFoto() { }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setRetainInstance(true);
        return inflater.inflate(R.layout.fragment_detalles_foto, container, false);
    }

    /*
    Añade los datos de la imagen al fragment
    pre: -
    post: se visualizan los datos en el fragment
     */
    public void añadirImagen(String titulo, String descrip, Bitmap imagen){
        ImageView img = getActivity().findViewById(R.id.imagenD);
        TextView tit = getActivity().findViewById(R.id.tituloD);
        TextView d = getActivity().findViewById(R.id.descripcion);
        img.setImageBitmap(imagen);
        tit.setText(titulo);
        d.setText(descrip);
    }

    /*
    Resetea los valores
    pre: -
    post: Se quedan vacios
     */
    public void reset(){
        ImageView img = getActivity().findViewById(R.id.imagenD);
        TextView tit = getActivity().findViewById(R.id.tituloD);
        TextView d = getActivity().findViewById(R.id.descripcion);
        img.setImageBitmap(null);
        tit.setText("");
        d.setText("");

    }

}
