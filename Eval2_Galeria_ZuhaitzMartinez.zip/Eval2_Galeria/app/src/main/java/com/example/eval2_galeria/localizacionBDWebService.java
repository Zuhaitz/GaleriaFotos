package com.example.eval2_galeria;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class localizacionBDWebService extends Worker {


    public localizacionBDWebService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }



    @NonNull
    @Override
    public Result doWork() {
        String op = getInputData().getString("operacion");
        String usu = getInputData().getString("usuario");
        String fecha = getInputData().getString("fecha");
        Double latitud = getInputData().getDouble("latitud", 0);
        Double longitud = getInputData().getDouble("longitud", 0);

        //Creamos la uri con los datos necesarios para la operacion
        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("operacion", op)
                .appendQueryParameter("usuario", usu)
                .appendQueryParameter("fecha", fecha)
                .appendQueryParameter("latitud", latitud.toString())
                .appendQueryParameter("longitud", longitud.toString());
        String param = builder.build().getEncodedQuery();

        //Generamos la conexion segura
        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/localizacion.php";
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);

        //Creamos la conexion
        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Comprobamos el estado de la conexion
        int statusCode = 0;
        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("Conexion Base datos", "" + statusCode);

        if (statusCode == 200) {
            try {
                //Recogemos el resultado
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                String line, result="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                inputStream.close();
                Log.i("Resultado LOCAL", "Resultado es: " + result);

                //Realizamos las operaciones necesarias segun el tipo de operacion
                if(op.equals("ModifLocal")){
                    if (result.equals("True")) return Result.success();
                    else return Result.failure();
                }else{
                    if(result.equals("False")) return Result.failure();
                    else {
                        Data resultado = jsonParser(result);
                        return Result.success(resultado);
                    }
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return Result.failure();
    }


    private Data jsonParser(String result) throws ParseException {
        Log.i("JSON", result);
        Double latitude = null, longitud = null;
        boolean get = false;

        if(!result.contains("null")){
            //Parseamos el JSON y recogemos los datos
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(result);

            //Recogemos las coordenadas
            latitude = Double.parseDouble((String) json.get("latitud"));
            longitud = Double.parseDouble((String) json.get("longitud"));
            get = true;
        }

        Data resultado = new Data.Builder()
                .put("get", get)
                .put("latitud", latitude)
                .put("longitud", longitud)
                .build();

        return resultado;
    }
}
