package com.example.eval2_galeria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    String usuario;
    EditText campoNom;
    EditText campoCon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        campoNom = findViewById(R.id.campoNom);
        campoCon = findViewById(R.id.campoCon);

        //Inicailizar el boton de inicio de sesion
        Button inicio = findViewById(R.id.iniciobtn);
        inicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usuario = campoNom.getText().toString();
                String c = campoCon.getText().toString();

                if (usuario.length()>0 && c.length()>0)
                    inicioSesionW(usuario, c);
                else{
                    Toast t = Toast.makeText(getApplicationContext(), "Introduce el usuario y la contraseña", Toast.LENGTH_SHORT);
                    t.show();
                }
            }
        });

        //Inicailizar el boton de registro
        Button regis = findViewById(R.id.registrobtn);
        regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegistroActivity.class);
                startActivity(i);
            }
        });

        //Comprobamos si se ha iniciado sesion en el dispositivo
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        if(!log.equals("")){
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        }
    }

    /*
    Realiza una conexion a la base de datos remota para comprobar el inicio de sesion
    pre: -
    post: Se indicara si se ha realizado correctamente el inicio de sesion
     */
    private void inicioSesionW(String nom, String con){
        //Recogemos el token del dispositivo para la mensajeria FCM
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String token = sp.getString("token", "");

        //Creamos el paquete de datos
        Data datos = new Data.Builder()
                .putString("operacion", "InicioSesion")
                .putString("nombre", nom)
                .putString("contra", con)
                .putString("token", token)
                .build();

        //Restringimos para que solo se lance con conexion
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(conexionBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                //Se ha iniciado sesion
                                SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
                                sp.edit().putString("nombreUsuario", usuario).apply();
                                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(i);
                                finish();

                            }else if (workInfo.getState().name().equals("FAILED")){
                                //No se ha inicado sesion correctamente
                                Toast t = Toast.makeText(getApplicationContext(), "Usuario o contraseña incorrectas", Toast.LENGTH_SHORT);
                                t.show();
                                campoCon.getText().clear();
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }
}
