package com.example.eval2_galeria;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ProtocolException;

import javax.net.ssl.HttpsURLConnection;

public class conexionEnviarMensajeFCM extends Worker {


    public conexionEnviarMensajeFCM(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        String usuario = getInputData().getString("usuario");

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("usuario", usuario);
        String param = builder.build().getEncodedQuery();

        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/enviarMensaje.php";

        //Generamos la conexion segura
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);


        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        int statusCode = 0;

        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("Conexion", "" + statusCode);

        if (statusCode == 200) {
            return Result.success();
        }

        return Result.failure();
    }
}
