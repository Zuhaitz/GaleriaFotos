package com.example.eval2_galeria;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class ServicioFirebase extends FirebaseMessagingService {
    public ServicioFirebase() {
    }

    //Si la aplicación está en background, se
    //muestra una notificación, pero no se
    //ejecuta este método
    public void onMessageReceived(RemoteMessage remoteMessage) {

        if (remoteMessage.getData().size() > 0) {
            //Si viene con datos
        }
        if (remoteMessage.getNotification() != null) {
            //Si el mensaje es una notificacion
            String body = remoteMessage.getNotification().getBody();
            String title = remoteMessage.getNotification().getTitle();
            String icon = remoteMessage.getNotification().getIcon();

            NotificationManager mana = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationCompat.Builder build = new NotificationCompat.Builder(getApplicationContext(), "added");

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                NotificationChannel canal = new NotificationChannel("added", "AddedElem", NotificationManager.IMPORTANCE_DEFAULT);
                canal.setDescription("Canal de notificación al recibir notificaciones");
                canal.enableLights(true);
                canal.setLightColor(Color.RED);
                mana.createNotificationChannel(canal);
            }

            build.setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setVibrate(new long[]{0, 1000, 500, 1000})
                    .setAutoCancel(true);

            mana.notify(2, build.build());
        }
    }

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        Log.i("Token FCM", s);
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        sp.edit().putString("token", s).apply();
    }

}
