package com.example.eval2_galeria;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapaActivity extends FragmentActivity implements OnMapReadyCallback {

    //TODO:
    //Coordenadas de España
    private String fechaElem;
    private double etiqLatitud = 40.416775;
    private double etiqLongitud = -3.703790;
    private double nuevaLat = 40.416775;
    private double nuevaLong = -3.703790;

    private boolean cambiar = false;
    private boolean tieneMarker = false;
    private boolean cargado = false;

    private TextView mensaje;
    private Button edit;
    private Button atras;
    private SupportMapFragment mapaFrag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa);

        edit = findViewById(R.id.mapaEditarbtn);
        atras = findViewById(R.id.mapaAtrasbtn);
        mensaje = findViewById(R.id.mapaMensaje);
        Bundle extras = getIntent().getExtras();

        if(savedInstanceState != null){
            fechaElem = savedInstanceState.getString("fecha");
            etiqLatitud = savedInstanceState.getDouble("latitud");
            etiqLongitud = savedInstanceState.getDouble("longitud");
            nuevaLat = savedInstanceState.getDouble("nuevaLat");
            nuevaLong = savedInstanceState.getDouble("nuevaLong");

            cambiar = savedInstanceState.getBoolean("cambiar");
            tieneMarker = savedInstanceState.getBoolean("tieneMarker");
            cargado = savedInstanceState.getBoolean("cargado");

            mensaje.setText(savedInstanceState.getString("mensaje"));
            edit.setText(savedInstanceState.getString("btnEdit"));
            atras.setText(savedInstanceState.getString("btnAtras"));
        }else if (extras != null) {
            fechaElem = extras.getString("fecha");
            getLocal();
        }

        mapaFrag =
                (SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.fragmentoMapa);
        mapaFrag.getMapAsync(this);

        //Inicializamos los listeners
        iniciarBTNListeners();

    }

    /*
    Inicializa todos los listeners de los botones
    pre: los botones ya creados
    post: los listeners inicializados
    */
    private void iniciarBTNListeners(){
        atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobamos el modo en el que esta el usuario
                if (cambiar) {
                    //Cancelamos los cambios
                    cambiar = false;
                    nuevaLat = etiqLatitud;
                    nuevaLong = etiqLatitud;
                    mapaFrag.getMapAsync(MapaActivity.this);
                    edit.setText("Editar");
                    atras.setText("Atrás");
                }else onBackPressed();
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Comrpobamos que ya se ha cargado todos los datos
                //antes de dejar al usuario hacer algo
                if(cargado) {
                    //Comprobamos el estado en el que esta el usuario
                    if (!cambiar) {
                        cambiar = true;
                        edit.setText("Aceptar");
                        atras.setText("Cancelar");
                    }else if(!latLongEqual()) {
                        editLocal();
                    }else{
                        Toast t = Toast.makeText(getApplicationContext(), "Seleccione un lugar en el mapa.", Toast.LENGTH_SHORT);
                        t.show();
                    }
                }
            }
        });
    }

    /*
    Se encarga de crear el worker para actualizar la localizacion
    pre: -
    post: muestra el resultado de la operacion
    */
    private void editLocal(){
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        //Generamos los datos a pasar
        Data datos = new Data.Builder()
                .putString("operacion", "ModifLocal")
                .putString("usuario", log)
                .putString("fecha", fechaElem)
                .putDouble("latitud", nuevaLat)
                .putDouble("longitud", nuevaLong)
                .build();

        //Creamos la restrccion de estar conectado a la red
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(localizacionBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        mensaje.setText("Actualizando localización...");

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker EDITLOCAL", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                //Realizamos lo cambios necesarios
                                etiqLatitud = nuevaLat;
                                etiqLongitud = nuevaLong;
                                tieneMarker = true;
                                edit.setText("Editar");
                                atras.setText("Atrás");
                                cambiar = false;
                                mapaFrag.getMapAsync(MapaActivity.this::onMapReady);

                                mensaje.setText("¡Localización actualizada con exito!");

                            }else if (workInfo.getState().name().equals("FAILED")){
                                Log.i("Error AÑADIR",  "ERROR");
                                mensaje.setText("¡Error! Compruebe la conexión.");
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }

    /*
    Se encarga de crear el worker para recoge la localizacion de la foto
    */
    private void getLocal(){
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        String log = sp.getString("nombreUsuario", "");

        //Generamos los datos a pasar
        Data datos = new Data.Builder()
                .putString("operacion", "GetLocal")
                .putString("usuario", log)
                .putString("fecha", fechaElem)
                .build();

        //Creamos la restrccion de estar conectado a la red
        Constraints restricciones = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(localizacionBDWebService.class)
                .setInputData(datos)
                .setConstraints(restricciones)
                .build();

        mensaje.setText("Cargando localización...");

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if(workInfo != null && workInfo.getState().isFinished()){
                            Log.i("Resultado worker GETLOCAL", workInfo.getState().name());
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                boolean get = workInfo.getOutputData().getBoolean("get", false);
                                Double lt = workInfo.getOutputData().getDouble("latitud", 0);
                                Double lg = workInfo.getOutputData().getDouble("longitud", 0);
                                cargado = true;

                                //Comprobamos si tiene localizacion
                                if(get){
                                    nuevaLong = lg;
                                    nuevaLat = lt;
                                    etiqLongitud = lg;
                                    etiqLatitud = lt;
                                    tieneMarker = true;
                                    mapaFrag.getMapAsync(MapaActivity.this::onMapReady);
                                    mensaje.setText("¡Foto localizada con exito!");

                                }else{
                                    mensaje.setText("Esta foto no dispone de localización.");
                                }

                            }else if (workInfo.getState().name().equals("FAILED")){
                                Log.i("Error GET",  "ERROR");
                                mensaje.setText("¡Error! Compruebe la conexión.");
                            }

                            WorkManager.getInstance().pruneWork();
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }

    /*
    Comprueba si ha añadido un nuevo marcador
    pre: -
    post: devuelve
            True: No se añadio un nuevo marcador
            False: Se añadio un nuevo marcador
    */
    private boolean latLongEqual(){
        return etiqLongitud == nuevaLong && etiqLatitud == nuevaLat;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate actualizar = CameraUpdateFactory.newLatLngZoom(new LatLng(etiqLatitud, etiqLongitud),4);
        googleMap.moveCamera(actualizar);

        //Comprobamos si el usuario ya estaba modificando el marcador
        if(cambiar && !latLongEqual()){
            actualizar = CameraUpdateFactory.newLatLngZoom(new LatLng(nuevaLat, nuevaLong),4);
            googleMap.moveCamera(actualizar);
            googleMap.addMarker(new MarkerOptions()
                    .position(new LatLng(nuevaLat, nuevaLong))
                    .title("Localización"));

        }else if(tieneMarker){
            //La foto tenia marcador
            googleMap.clear();
            googleMap.addMarker(new MarkerOptions()
                    .position(new LatLng(etiqLatitud, etiqLongitud))
                    .title("Localización"));

        }else{
            googleMap.clear();
        }

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if(cambiar) {
                    //Limpiamos todos los demas marcadores
                    googleMap.clear();

                    CameraUpdate actualizar = CameraUpdateFactory.newLatLng(latLng);
                    googleMap.moveCamera(actualizar);
                    googleMap.addMarker(new MarkerOptions()
                            .position(new LatLng(latLng.latitude, latLng.longitude))
                            .title("Localización"));

                    //Actualizamos las nuevas coordenadas posibles del nuevo marcador
                    nuevaLat = latLng.latitude;
                    nuevaLong = latLng.longitude;
                }
            }
        });
    }

    //TODO: Mensaje de botones
    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("fecha", fechaElem);
        outState.putDouble("latitud", etiqLatitud);
        outState.putDouble("longitud",etiqLongitud);
        outState.putDouble("nuevaLat", nuevaLat);
        outState.putDouble("nuevaLong", nuevaLong);

        outState.putBoolean("cambiar", cambiar);
        outState.putBoolean("tieneMarker", tieneMarker);
        outState.putBoolean("cargado", cargado);

        outState.putString("mensaje", mensaje.getText().toString());
        outState.putString("btnEdit", edit.getText().toString());
        outState.putString("btnAtras", atras.getText().toString());
    }
}
