package com.example.eval2_galeria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

public class ImageCPActivity extends AppCompatActivity {

    ListaCPImagenes listaFrag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_c_p);

        listaFrag = (ListaCPImagenes) getSupportFragmentManager().findFragmentById(R.id.listaAlma);

        //Añdimos la barra con la accion de volver
        Toolbar barra = findViewById(R.id.barraCP);
        setSupportActionBar(barra);
        barra.setNavigationIcon(getResources().getDrawable(R.drawable.baseline_reply_black_18dp));
        barra.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        //Comprobamos si aun tiene los permisos
        if(tienePermisos()){
            Intent i = new Intent(ImageCPActivity.this, MainActivity.class);
            i.putExtra("permiso", false);
            startActivity(i);
            finish();
        }else{
            listaFrag.limpiar();
            listaFrag.inicializar();
        }
    }


    /*
    Se comprueba si se tienen los permisos necesarios
    pre: -
    post: se devuleve un booleano con el resultado
            TRUE: No tiene permisos
            FALSE: Tiene los permisos
     */
    private boolean tienePermisos(){
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED;
    }
}
