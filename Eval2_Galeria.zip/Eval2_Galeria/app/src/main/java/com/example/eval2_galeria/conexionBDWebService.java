package com.example.eval2_galeria;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class conexionBDWebService extends Worker {

    public conexionBDWebService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        String op = getInputData().getString("op");
        String nombre = getInputData().getString("nombre");
        String contra = getInputData().getString("contra");

        String result = usuarioBDWeb(nombre, contra);

        if (result.equals("True")) return Result.success();
        else return Result.failure();
    }


    private String usuarioBDWeb(@NonNull String nombre, @NonNull String contra){
        Log.i("Conexion", "Nombre y Contra: " + nombre + contra);

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("nombre", nombre)
                .appendQueryParameter("contra", contra);
        String param = builder.build().getEncodedQuery();

        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/usuarios.php";

        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);

        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        int statusCode = 0;

        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("Conexion Base datos", "" + statusCode);

        if (statusCode == 200) {
            try {
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                String line, result="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                inputStream.close();
                Log.i("Resultado", "Resultado es: " + result);

                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return "False";
    }
}
