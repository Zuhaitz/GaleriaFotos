package com.example.eval2_galeria;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class imagenesBDWebService extends Worker {

    public imagenesBDWebService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        //Recogemos e inicializamos los datos necesarios
        String op = getInputData().getString("operacion");
        String usu = getInputData().getString("usuario");
        String result = "Error";
        Uri.Builder builder;
        String param;

        //Comprobamos la operacion deseada
        switch (op){
            case "AnadirImagen":
                String fecha = getInputData().getString("fecha");
                String titulo = getInputData().getString("titulo");
                String descrip = getInputData().getString("descrip");
                String img = getInputData().getString("imagen");
                String img64 = "";

                try {
                    //Cargamos la imagen que se a guardado anteriormente en local
                    Bitmap b = BitmapFactory.decodeStream(getApplicationContext().openFileInput(img));
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    b.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] imgTrasform = stream.toByteArray();
                    img64 = Base64.encodeToString(imgTrasform, Base64.DEFAULT);

                    //La borramos para que no ocupe espacio
                    File dir = getApplicationContext().getFilesDir();
                    File file = new File(dir, img);
                    boolean deleted = file.delete();

                    Log.i("Imagen borrada", "" + deleted);

                }catch (Exception e){
                    e.printStackTrace();
                }

                //Creamos la uri con los datos necesarios para la operacion
                builder = new Uri.Builder()
                        .appendQueryParameter("operacion", op)
                        .appendQueryParameter("usuario", usu)
                        .appendQueryParameter("fecha", fecha)
                        .appendQueryParameter("titulo", titulo)
                        .appendQueryParameter("descrip", descrip)
                        .appendQueryParameter("imagen", img64);
                param = builder.build().getEncodedQuery();

                //Esperamos el resultado de la conexion
                result = imagenesBDWeb(param);

                break;

            case "BorrarImagenes":
                String[] idBorrar = getInputData().getStringArray("idBorrar");

                //Creamos la uri con los datos necesarios para la operacion
                builder = new Uri.Builder()
                        .appendQueryParameter("operacion", op)
                        .appendQueryParameter("usuario", usu);

                //Vamos añadiendo una a una todas las fotos marcadas para borrar
                for (String f : idBorrar) {
                    builder.appendQueryParameter("idBorrar[]", f);
                }
                param = builder.build().getEncodedQuery();

                //Esperamos el resultado de la conexion
                result = imagenesBDWeb(param);

                break;

            case "ModifImagen":
                String f = getInputData().getString("fecha");
                String t = getInputData().getString("titulo");
                String d = getInputData().getString("descrip");

                //Creamos la uri con los datos necesarios para la operacion
                builder = new Uri.Builder()
                        .appendQueryParameter("operacion", op)
                        .appendQueryParameter("usuario", usu)
                        .appendQueryParameter("fecha", f)
                        .appendQueryParameter("titulo", t)
                        .appendQueryParameter("descrip", d);
                param = builder.build().getEncodedQuery();

                //Esperamos el resultado de la conexion
                result = imagenesBDWeb(param);

                break;

        }

        //Comprobamos si se ha realizado correctamente
        if (result.equals("True")) return Result.success();
        else {
            Data resultados = new Data.Builder()
                    .putString("resultado", result)
                    .build();
            return Result.failure(resultados);
        }

    }


    private String imagenesBDWeb(String param) {

        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/imagenes.php";

        //Generamos la conexion segura
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);

        //Creamos la conexion
        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Comprobamos el estado de la conexion
        int statusCode = 0;
        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("Conexion Base datos", "" + statusCode);

        if (statusCode == 200) {
            try {
                //Recogemos el resultado
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                String line, result="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                inputStream.close();
                Log.i("Resultado", "Resultado es: " + result);

                return result;
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return "False";
    }

}
