package com.example.eval2_galeria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText campoNom;
    EditText campoCon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        campoNom = findViewById(R.id.campoNom);
        campoCon = findViewById(R.id.campoCon);

        Button inicio = findViewById(R.id.iniciobtn);
        inicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = campoNom.getText().toString();
                String c = campoCon.getText().toString();

                inicioSesionW(n, c);
            }
        });
    }


    private void inicioSesionW(String nom, String con){
        Data datos = new Data.Builder()
                .putString("nombre", nom)
                .putString("contra", con)
                .build();

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(conexionBDWebService.class)
                .setInputData(datos)
                .build();

        WorkManager.getInstance().getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        Log.i("Resultado worker", workInfo.getState().name());
                        if(workInfo != null && workInfo.getState().isFinished()){
                            if (workInfo.getState().name().equals("SUCCEEDED")){
                                //Se ha iniciado sesion

                            }else if (workInfo.getState().name().equals("FAILED")){
                                //No se ha inicado sesion correctamente
                                Toast t = Toast.makeText(getApplicationContext(), "Usuario o contraseña erroneas", Toast.LENGTH_SHORT);
                                t.show();
                                campoCon.getText().clear();
                            }
                        }
                    }
                });
        WorkManager.getInstance().enqueue(otwr);
    }
}
