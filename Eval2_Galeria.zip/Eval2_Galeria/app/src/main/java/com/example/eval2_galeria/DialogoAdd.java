package com.example.eval2_galeria;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.io.FileNotFoundException;
import java.io.InputStream;

import static android.app.Activity.RESULT_OK;

public class DialogoAdd extends DialogFragment {

    ListenerDialogoAdd listener;
    View aspecto;
    TextView titulo;
    TextView descrip;
    ImageView imageView;
    Button botonAceptar;

    @Nullable
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState){
        super.onCreateDialog(savedInstanceState);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Añadir nuevo elemento");
        LayoutInflater inflater = getActivity().getLayoutInflater();
        aspecto = inflater.inflate(R.layout.dialoganadir, null);
        builder.setView(aspecto);

        listener = (MainActivity) getActivity();

        //Recogemos los diferentes elementos del Dialog, para luego poder revisar su contenido
        titulo = aspecto.findViewById(R.id.tituloA);
        descrip = aspecto.findViewById(R.id.descripA);
        imageView = aspecto.findViewById(R.id.imagenA);
        botonAceptar = aspecto.findViewById(R.id.guardar);

        crearListeners();

        return builder.create();
    }

    /*
    Se encarga de crear los listeners del Dialog
    pre: -
    post: Los botones son funcinales
     */
    private void crearListeners(){
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Aqui se solicita al usuario que escoja una imagen de su movil
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, 0);
            }
        });

        botonAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Pulsado el boton", "Titulo: " + titulo.getText() + ", Descrip: " + descrip.getText() + ", Imagen: " + (imageView.getDrawable() != null));

                //Se comprueba si todos los aparatados se rellenaron
                if(titulo.getText().length() > 0 && descrip.getText().length() > 0 && imageView.getDrawable() != null){
                    Drawable d = imageView.getDrawable();
                    Bitmap bitmap = ((BitmapDrawable)d).getBitmap();
                    String tit = titulo.getText().toString();
                    String des = descrip.getText().toString();

                    listener.pulsarGuardar(tit, des, bitmap);
                    getDialog().dismiss();
                }else{
                    //Se crea un Toast para notificar al usuario que falta algo
                    Toast toast = Toast.makeText(getContext(), "Rellena todos los apartados",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i("Cogido imagen", "Entra en onActivityResult");

        //Comprobamos que la solicitud de la imagen sea correcta
        if(requestCode == 0 && resultCode == RESULT_OK){
            try{
                Log.i("Cogido imagen", "Entra en try");

                //Recogemosla imagen seleccionada y se la asignamos a la imagen del Dialog
                Uri imageUri = data.getData();
                InputStream imageStream = getActivity().getContentResolver().openInputStream(imageUri);
                Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

                //Comprobamos que la imagen no se demasiado grande para que no de error despues
                if(selectedImage.getHeight() > 3072 || selectedImage.getWidth() > 3072){
                    Toast toast = Toast.makeText(getContext(), "Imagen demasiado grande",Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    imageView.setImageBitmap(selectedImage);
                    imageView.setBackground(null);
                }

            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }
    }

    public interface ListenerDialogoAdd{
        void pulsarGuardar(String titulo, String descrip, Bitmap img);
    }
}
