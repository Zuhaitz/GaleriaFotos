package com.example.eval2_galeria;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class BaseDatos extends SQLiteOpenHelper {

    public BaseDatos(@Nullable Context context, @Nullable String name,
                     @Nullable SQLiteDatabase.CursorFactory factory, int version){
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Galeria ('Fecha' TEXT PRIMARY KEY NOT NULL, 'Titulo' TEXT, 'Descripcion' TEXT, 'Imagen' BLOB)");
}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /*
    Añade un elemnto a la base de datos
    pre: -
    post: añadido el nuevo elemento
     */
    public void añadirElemento(String fecha, String titulo, String descripcion, Bitmap image){
        byte[] data = getBitmapAsByteArray(image);
        ContentValues nuevo = new ContentValues();

        Log.i("Añadir Fecha", "Fecha: " + fecha);
        nuevo.put("Fecha", fecha);
        nuevo.put("Titulo", titulo);
        nuevo.put("Descripcion", descripcion);
        nuevo.put("Imagen", data);

        SQLiteDatabase bd = getWritableDatabase();
        bd.insert("Galeria", null, nuevo);

    }

    /*
    Borra una lista de elementos dada su clase
    pre: -
    post: se han borrado todas las lineas en la base de datos
     */
    public void borrarElementos(ArrayList<String> claves){
        SQLiteDatabase bd = getWritableDatabase();
        for (String c : claves){
            bd.delete("Galeria", "Fecha='" + c + "'", null);
        }
    }

    /*
    Modifica los datos de un elemento
    pre: -
    post: se modifica el elemento
     */
    public void modificarElemento(String f, String t, String d){
        SQLiteDatabase bd = getWritableDatabase();
        ContentValues modificacion = new ContentValues();
        modificacion.put("Titulo", t);
        modificacion.put("Descripcion", d);
        String[] arg = new String[] {f};
        bd.update("Galeria", modificacion, "Fecha=?", arg);
    }


    /*
    Devuelve una lista de cuartetos con los datos necesarios de cada elemento
    pre: -
    post: la lista de elementos
     */
    public List<Quartet<String, String, String, Bitmap>> getListaElementos(){
        SQLiteDatabase bd = getWritableDatabase();
        Cursor c = bd.rawQuery("SELECT * FROM Galeria", null);
        List<Quartet<String, String, String, Bitmap>> resul = new ArrayList<>();

        while(c.moveToNext()){
            Log.i("Base de datos", "Fecha: " + c.getString(0));
            String fecha = c.getString(0);
            String titulo = c.getString(1);
            String descrip = c.getString(2);
            byte[] imagen = c.getBlob(3);
            Bitmap img = BitmapFactory.decodeByteArray(imagen, 0, imagen.length);
            resul.add(new Quartet<String, String, String, Bitmap>(fecha, titulo, descrip, img));
        }

        c.close();

        return resul;
    }

    /*
    Source: https://stackoverflow.com/questions/9357668/how-to-store-image-in-sqlite-database
    Creador: Jram
    Editado: Community
     */
    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, outputStream);
        return outputStream.toByteArray();
    }


    /*
    Source: https://stackoverflow.com/questions/6010843/java-how-to-store-data-triple-in-a-list
    Creador: Bala R
    Editado: Osguima3
    Modificado: Por mi para adaptarlo a 4 atributos
     */
    public class Quartet<T, U, V, W> {

        private final T first;
        private final U second;
        private final V third;
        private final W fourth;

        public Quartet(T first, U second, V third, W fourth) {
            this.first = first;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
        }

        public T getFirst() { return first; }
        public U getSecond() { return second; }
        public V getThird() { return third; }
        public W getFourth() { return fourth; }
    }
}
