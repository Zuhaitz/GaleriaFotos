package com.example.eval2_galeria;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.ListFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;


public class ListaFotos extends ListFragment {

    private listenerFragment listener;
    private AdapterListView adap;
    private ArrayList<String> fechas;
    private ArrayList<Bitmap> imagenes;
    private ArrayList<String> titulos;
    private ArrayList<String> descrip;

    private BaseDatos GestorDB;


    public ListaFotos() { }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setRetainInstance para que las imagenes se mantengan
        setRetainInstance(true);

        //Inicailizamos las variables
        fechas = new ArrayList<>();
        titulos = new ArrayList<>();
        imagenes = new ArrayList<>();
        descrip = new ArrayList<>();

        GestorDB = new BaseDatos(getActivity(), "GaleriaDB", null, 1);
        inicializar();
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        adap = new AdapterListView(getActivity(), titulos, imagenes);

        if(savedInstanceState!=null){
            ArrayList<Integer> s = savedInstanceState.getIntegerArrayList("checked");
            adap.setCheckedList(s);
        }

        setListAdapter(adap);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l, v, position, id);
        listener.seleccionarElemento(fechas.get(position), titulos.get(position), descrip.get(position), imagenes.get(position));
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            listener = (listenerFragment) context;
        }
        catch (ClassCastException e) {
            throw new ClassCastException("La clase " + context.toString()
                        + "debe implementar listenerFragment");
        }
    }


    public void añadirImagen(String titulo, String des, Bitmap img){
        Date currentTime = Calendar.getInstance().getTime();
        //Añadimos el nuevo elemento a la lista
        fechas.add(currentTime.toString());
        titulos.add(titulo);
        imagenes.add(img);
        descrip.add(des);
        adap.notifyDataSetChanged();

        //LLamamos al metodo para añadirlo en la base de datos
        GestorDB.añadirElemento(currentTime.toString(), titulo, des, img);

        //Enviamos al usuario la notificacion de elemento añadido
        enviarNotificacion(titulo, img);
    }

    /*
    Borra todos los elemntos que han sido marcados al pulsar el boton de 'Borrar'
    pre: se pulso el boton y hay elementos marcados
    post: se borran los elementos marcados
     */
    public void borrarChecked(){
        //Recogemos las posiciones de los elementos marcados y los ordenamos en forma descendente
        ArrayList<Integer> r = adap.getCheckedList();
        Collections.sort(r,  Collections.reverseOrder());
        Log.i("Borrar Checked", "Lista ordenada: " + r.toString());

        //Recogemos las fechas de las respectivas posiciones y los borramos de la base de datos
        ArrayList<String> l = new ArrayList<>();
        for (int i : r){
            l.add(fechas.get(i));
            //Limpiamos los valores de la lista
            fechas.remove(i);
            titulos.remove(i);
            descrip.remove(i);
            imagenes.remove(i);
        }
        GestorDB.borrarElementos(l);
        adap.resetCheckedList();
        adap.notifyDataSetChanged();

        listener.comprobar();

    }

    /*
    Modifica la lista con los nuevos datos
    pre: se modifique un elemento
    post: aparece el elemento modificado
     */
    public void modificarLista(String fecha, String titulo, String des) {
        int pos = fechas.indexOf(fecha);
        titulos.set(pos, titulo);
        descrip.set(pos, des);
        adap.notifyDataSetChanged();
    }

    /*
    Inicializa los elementos de la lista
    pre: Que las listas esten vacias
    post: las listas tienen los elementos asignados
     */
    public void inicializar(){
        List<BaseDatos.Quartet<String, String, String, Bitmap>> resul = GestorDB.getListaElementos();

        for (BaseDatos.Quartet<String, String, String, Bitmap> elem : resul) {
            fechas.add(elem.getFirst());
            titulos.add(elem.getSecond());
            descrip.add(elem.getThird());
            imagenes.add(elem.getFourth());
        }

        Log.i("Lista fechas", fechas.toString());
    }

    /*
    Envia una notificación cuando un elemento se añada
    pre: se añade un nuevo elemento
    post: se envia la notificacion
     */
    private void enviarNotificacion(String titulo, Bitmap img){
        NotificationManager mana = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder build = new NotificationCompat.Builder(getContext(), "added");

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel canal = new NotificationChannel("added", "AddedElem", NotificationManager.IMPORTANCE_DEFAULT);
            canal.setDescription("Canal de notificación al añadir nuevos elementos");
            canal.enableLights(true);
            canal.setLightColor(Color.RED);
            mana.createNotificationChannel(canal);
        }

        build.setSmallIcon(android.R.drawable.arrow_up_float)
                .setContentTitle("¡Nuevo elemento añadido!")
                .setContentText("Se ha añadido con exito un elemento a tu galeria personal.")
                .setSubText(titulo)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .setAutoCancel(true);

        mana.notify(1, build.build());
    }


    /*
    Limpia las listas
    pre: -
    post: se vacian las listas
     */
    public void limpiar(){
        fechas.clear();
        titulos.clear();
        descrip.clear();
        imagenes.clear();

        adap.notifyDataSetChanged();
    }

    public interface listenerFragment{
        void seleccionarElemento(String fecha, String elemento, String descrip, Bitmap imagen);
        void comprobar();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArrayList("titulos", titulos);
        outState.putStringArrayList("descrip", descrip);
        outState.putIntegerArrayList("checked", adap.getCheckedList());

    }
}
