package com.example.eval2_galeria;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;


import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity implements ListaFotos.listenerFragment,
                                                                DialogoAdd.ListenerDialogoAdd {
    private boolean inicio = true;
    private boolean cambio = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Se le añade un listener al boton para lanzar un Dialog
        //para que el usuario pueda añadir un elemento
        Button button = findViewById(R.id.anadir);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogo = new DialogoAdd();
                dialogo.show(getSupportFragmentManager(), "anadir");
            }
        });

        //Recogemos el boton de borrado y lo ocultamos,
        // para que solo sea visible al marcar una checkbox
        Button borrar = findViewById(R.id.borrar);
        borrar.setVisibility(View.GONE);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListaFotos lista = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
                lista.borrarChecked();
                Button borrar = findViewById(R.id.borrar);
                borrar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Entra en onStart", "A vuelto correctamente");

        //Se controla si el usuario le dio hacia atras en vez de al boton volver
        if(!inicio){
            if(!cambio){
                ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
                list.limpiar();
                list.inicializar();

            }else cambio = false;
        }

        inicio = false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle extras = intent.getExtras();
        Log.i("Entra en NewIntent", "A vuelto correctamente");

        //Aqui controlamos cuando el usuario decide volver y a modificado algun dato
        if (extras != null){
            Log.i("Entra en NewIntent", "Recibe extras");
            ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
            list.modificarLista(extras.getString("fecha"), extras.getString("titulo"), extras.getString("descrip"));
        }
        cambio = true;
    }

    public void seleccionarElemento(String fecha, String elemento, String descrip, Bitmap imagen) {

        //Comprobamos si el movil esta en apaisado
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            //Le pasamos al otro fragment la informacion
            DetallesFoto det = (DetallesFoto) getSupportFragmentManager().findFragmentById(R.id.detalles);
            det.añadirImagen(elemento, descrip, imagen);

        }
        else {
            //Creamos un intent y le enviamos a la otra actividad la informacion
            Intent i = new Intent(MainActivity.this, DetallesActivity.class);
            i.putExtra("fecha", fecha);
            i.putExtra("titulo", elemento);
            i.putExtra("descrip", descrip);

            //Guardamos la imagen en local, ya que no es conveniente
            //pasar imagenes a traves de los intents
            String path = createImageFromBitmap(imagen);
            i.putExtra("imagen", path);
            startActivity(i);

        }
    }

    // Source: https://stackoverflow.com/questions/4352172/how-do-you-pass-images-bitmaps-between-android-activities-using-bundles
    // Creador: Illegal Argument
    public String createImageFromBitmap(Bitmap bitmap) {
        String fileName = "myImage";//no .png or .jpg needed
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            FileOutputStream fo = openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            // remember close file output
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }


    @Override
    public void pulsarGuardar(String titulo, String descrip, Bitmap img) {
        //Recojemos los datos introducidos en el dialog, y los añadimos a la lista
        ListaFotos list = (ListaFotos) getSupportFragmentManager().findFragmentById(R.id.listafotos);
        list.añadirImagen(titulo, descrip, img);
    }

    @Override
    public void comprobar(){
        //Comprobamos si esta en landscape para resetar la imagen de detalles
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
            //Reseteamos el fragment
            DetallesFoto det = (DetallesFoto) getSupportFragmentManager().findFragmentById(R.id.detalles);
            det.reset();

        }
    }


}
