package com.example.eval2_galeria;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class listarImagenesBDWebService extends Worker {

    public listarImagenesBDWebService(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        String usuario = getInputData().getString("usuario");

        //Creamos la uri con los datos necesarios para la operacion
        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("usuario", usuario);
        String param = builder.build().getEncodedQuery();

        String dir = "https://134.209.235.115/zmartinez015/WEB/eval2_galeria/listarImagenes.php";

        //Generamos la conexion segura
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance()
                .crearConexionSegura(getApplicationContext(), dir);

        //Creamos la conexion
        try {
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(param);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        //Comprobamos el estado de la conexion
        int statusCode = 0;
        try {
            statusCode = urlConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }


        if (statusCode == 200) {
            try {
                //Recogemos el resultado
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                String line, result="";
                while ((line = bufferedReader.readLine()) != null){
                    result += line;
                }
                inputStream.close();

                //Parseamos el JSON y recogemos los datos
                JSONParser parser = new JSONParser();
                JSONArray json = (JSONArray) parser.parse(result);

                JSONObject o;
                String[] fechas = new String[json.size()];
                String[] titulos = new String[json.size()];
                String[] descripciones = new String[json.size()];
                String[] imagenes = new String[json.size()];

                for (int i = 0; i<json.size(); i++){
                    o = (JSONObject) json.get(i);
                    //Log.i("JSON elemento " + i, o.toString());

                    String fecha = (String) o.get("fecha");
                    //Log.i("Fecha " + i, fecha);

                    //Recogemos losa datos y los guardamos en un array
                    fechas[i] = fecha;
                    titulos[i] = (String) o.get("titulo");
                    descripciones[i] = (String) o.get("descripcion");

                    //Recogemos las imagenes y las guardamos
                    byte[] imgByte = Base64.decode((String) o.get("img"), Base64.DEFAULT);
                    Bitmap img = BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length);
                    imagenes[i] = createImageFromBitmap(img, fecha);

                }

                //Creamos un paquete con los datos de las imagenes a mostrar
                Data resultados = new Data.Builder()
                        .putStringArray("fechas", fechas)
                        .putStringArray("titulos", titulos)
                        .putStringArray("descripciones", descripciones)
                        .putStringArray("imagenes", imagenes)
                        .build();

                return Result.success(resultados);
            }catch (Exception e) {
                e.printStackTrace();
            }
        }

        return Result.failure();
    }

    // Source: https://stackoverflow.com/questions/4352172/how-do-you-pass-images-bitmaps-between-android-activities-using-bundles
    // Creador: Illegal Argument
    // Modificado por Zuhaitz
    public String createImageFromBitmap(Bitmap bitmap, String fecha) {
        String fileName = "IMG_" + fecha + "_";//no .png or .jpg needed
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes);
            FileOutputStream fo = getApplicationContext().openFileOutput(fileName, Context.MODE_PRIVATE);
            fo.write(bytes.toByteArray());
            // remember close file output
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
            fileName = null;
        }
        return fileName;
    }
}
