package com.example.eval2_galeria;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;


public class DetallesActivity extends AppCompatActivity implements DialogoModificar.ListenerDialogModif{

    private String fechaElem;
    private boolean modif = false;
    private TextView tit;
    private TextView des;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);

        tit = findViewById(R.id.tituloD);
        des = findViewById(R.id.descripcion);

        //Recogemos los datos de la foto a mostrar
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ImageView i = findViewById(R.id.imagenD);
            try {
                //Cargamos la imagen que se a guardado anteriormente en local
                Bitmap b = BitmapFactory.decodeStream(this.openFileInput("myImage"));
                i.setImageBitmap(b);

            }catch (Exception e){
                e.printStackTrace();
            }

            //Añadimos el resto de los datos
            tit.setText(extras.getString("titulo"));
            des.setText(extras.getString("descrip"));
            fechaElem = extras.getString("fecha");
        }

        //Cargamos los datos guardado si existen
        if(savedInstanceState!=null) {
            fechaElem = savedInstanceState.getString("fecha");
            modif = savedInstanceState.getBoolean("modif");
            tit.setText(savedInstanceState.getString("titulo"));
            des.setText(savedInstanceState.getString("descrip"));
        }


        crearListeners();

    }


    private void crearListeners(){
        Button volver = findViewById(R.id.volver);
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DetallesActivity.this, MainActivity.class);
                //Si se ha modificado algo se le enviara a la actividad principal
                //los datos para que los actualice
                if(modif){
                    i.putExtra("fecha", fechaElem);
                    i.putExtra("titulo", tit.getText());
                    i.putExtra("descrip", des.getText());
                }
                startActivity(i);
                finish();
            }
        });

        Button edit = findViewById(R.id.editarBtn);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment dialogo = new DialogoModificar();

                //Pasamos los datos anteriores al dialog
                Bundle args = new Bundle();
                args.putString("titulo", tit.getText().toString());
                args.putString("descrip", des.getText().toString());
                dialogo.setArguments(args);

                dialogo.show(getSupportFragmentManager(), "modif");
            }
        });
    }


    /*
    Metodo al que se llama cuando se acepta la modificacion en el DialogModificar
    pre: pulsar el boton
    post: se modifican los valores de la imagen
     */
    @Override
    public void pulsarModif(String titulo, String descrip) {
        tit.setText(titulo);
        des.setText(descrip);

        //Modificamos los valores en la base de datos
        BaseDatos GestorDB = new BaseDatos(this, "GaleriaDB", null, 1);
        GestorDB.modificarElemento(fechaElem, titulo, descrip);

        modif=true;
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("fecha", fechaElem);
        outState.putString("titulo", tit.getText().toString());
        outState.putString("descrip", des.getText().toString());
        outState.putBoolean("modif", modif);

    }
}
