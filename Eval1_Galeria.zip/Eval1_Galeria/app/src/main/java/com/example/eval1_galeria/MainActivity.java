package com.example.eval1_galeria;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ListaFotos.listenerFragment {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void seleccionarElemento(String elemento) {


        if (getSupportFragmentManager().findFragmentById(R.id.listafotos) != null){
            //TODO: Enviar info al otro fragment

        }
        else {
            //TODO: Crear intent para enviar la info

        }
    }
}
