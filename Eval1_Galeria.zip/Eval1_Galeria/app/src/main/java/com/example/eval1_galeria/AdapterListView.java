package com.example.eval1_galeria;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

public class AdapterListView extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private String[] datos;
    private int[] imagenes;

    public AdapterListView(Context vContext, String[] vDatos, int[] vImagenes){
        context = vContext;
        datos = vDatos;
        imagenes = vImagenes;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return datos.length;
    }

    @Override
    public Object getItem(int position) {
        return datos[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.aspecto_lista, null);
        TextView titulo = (TextView) convertView.findViewById(R.id.tituloP);
        ImageView imagen = (ImageView) convertView.findViewById(R.id.imagen);
        CheckBox check = (CheckBox) convertView.findViewById(R.id.checkBox);

        titulo.setText(datos[position]);
        imagen.setImageResource(imagenes[position]);
        check.setActivated(false);

        return convertView;
    }
}
