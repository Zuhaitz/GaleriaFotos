package com.example.eval1_galeria;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterListView extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    private ArrayList<String> datos;
    private ArrayList<Bitmap> imagenes;
    private ArrayList<Integer> checkedList;

    public AdapterListView(Context vContext, ArrayList<String> vDatos, ArrayList<Bitmap> vImagenes){
        context = vContext;
        datos = vDatos;
        imagenes = vImagenes;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        checkedList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int position) {
        return datos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.aspecto_lista, null);
        TextView titulo = convertView.findViewById(R.id.tituloP);
        ImageView imagen = convertView.findViewById(R.id.imagenP);
        CheckBox check = convertView.findViewById(R.id.checkBox);

        titulo.setText(datos.get(position));
        imagen.setImageBitmap(imagenes.get(position));
        check.setActivated(false);
        check.setTag(position);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = ((CheckBox) v).isChecked();
                Log.i("Check Listener", "Se marco un objeto " + v.getTag() + ": " + checked);

                if (checked) checkedList.add((int) v.getTag());
                else checkedList.remove(v.getTag());

                Log.i("Check Listener", "Lista: " + checkedList.toString());

                //Recogemos el boton de borrar, y vemos si tienes que ser visible
                Button b = ((MainActivity)context).findViewById(R.id.borrar);
                if(checkedList.isEmpty()) b.setVisibility(View.GONE);
                else b.setVisibility(View.VISIBLE);

            }
        });

        if (checkedList.contains(position)) check.setChecked(true);


        return convertView;
    }

    public ArrayList<Integer> getCheckedList(){ return checkedList; }

    public void resetCheckedList(){ checkedList.clear(); }

    public void setCheckedList(ArrayList<Integer> ch){
        checkedList = ch;
        if(!ch.isEmpty()) ((MainActivity)context).findViewById(R.id.borrar).setVisibility(View.VISIBLE);
    }

}
