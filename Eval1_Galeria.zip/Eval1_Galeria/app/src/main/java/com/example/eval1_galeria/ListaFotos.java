package com.example.eval1_galeria;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.ListFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class ListaFotos extends ListFragment {

    private listenerFragment listener;
    private int[] imagenes;
    private String[] titulos;

    public ListaFotos() {
        //TODO: Cargar de la base de datos

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String[] tit= {"UWU", "Esta esta guay", "Esta foto esta bastante guay porque me parece basteante bien dibujada"};
        int[] img = {R.drawable.yotsuba_0o0, R.drawable.yotsuba_confused, R.drawable.yotsuba_eh};
        titulos = tit;
        imagenes = img;

    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);

        //TODO: Cargar de la base de datos

        AdapterListView adap = new AdapterListView(getActivity(), titulos, imagenes);
        setListAdapter(adap);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l, v, position, id);
        //TODO
        //listener.seleccionarElemento(datos[position]);
    }

    public void onAttach(Context context) {
        super.onAttach(context);

        try{
            listener = (listenerFragment) context;
        }
        catch (ClassCastException e) {
            throw new ClassCastException("La clase " + context.toString()
                        + "debe implementar listenerFragment");
        }
    }

    public interface listenerFragment{
        void seleccionarElemento(String elemento);
    }
}
